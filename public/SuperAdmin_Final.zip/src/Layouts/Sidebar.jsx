import React, { useState } from 'react';
import styled from 'styled-components';
import { useSidebarContext } from '../Dashboard/DashboardLayout';
import { Icon } from '@iconify/react';
import 'animate.css';
import { Link } from 'react-router-dom';
import { useEffect } from 'react';

const Container = styled.div`
    background-color: var(--sidebarBackground);
    transition: width 0.2s ease;
    height: 100vh;

    @media screen and (max-width: 1000px) and (min-width: 0px) {
        width: 200px;
        transition: width 0.2s ease-in !important;
    }
    
    .crossicon{
        display: none !important;
    }

    @media screen and (max-width: 1000px) {
        .crossicon{
            display: block !important;
            margin-left: 11% !important;
            margin-top: -5% !important;
            cursor: pointer
        }

    }

    .itemVisible, .subitemVisible {
        opacity: 1;
        position: static;
        transition: opacity 0.3s ease;
    }

    .itemHidden,  .addonSubitem {
        display: none;
        z-index: 999;
        position: absolute;
        left: 3.4%;
        transition: opacity 0.2s ease;
        padding: 0.63% 2% 0.63% 2%;
        margin-top: -0.72% !important;
    }

    .menus:hover .itemHidden{
        display: block !important;
        background-color: var(--buttonBgColor) !important;
        color: #fff;
    }

    .addonmenu:hover .addonSubitem {
        display: block;
        background-color: var(--buttonBgColor) !important;
        color: #fff;
    }

    .menus:hover .icon{
        color: #fff;
    }

    .submenus:hover{
        background-color: var(--buttonBgColor);
    }
    
`;

const Sidebar = () => {

    const { sidebaropen } = useSidebarContext();

    const {toggleSidebar } = useSidebarContext();     //useContext

    // const sidebarItems = [
    //     { name: "Dashboard", icon: <Icon icon="ant-design:dashboard-outlined" width="1.8em" height="1.8em"  style={{color: '#000'}} />, path: "/" },
    //     { name: "Users", icon: <Icon icon="ant-design:dashboard-outlined" width="1.8em" height="1.8em"  style={{color: '#000'}} />, path: "/item2" },
    //     { name: "Dashboard", icon: <Icon icon="ant-design:dashboard-outlined" width="1.8em" height="1.8em"  style={{color: '#000'}} />, path: "/item3" },
    // ];

    useEffect(()=>{
        if(window.location.reload===true){
            navigate('/')
        }
    })

    console.log(sidebaropen, 'sidebar')

    const toggleicon = window.innerWidth <= 1000 ? !sidebaropen : sidebaropen;

    return (
        <>
            <Container>
                <div className='container-fluid'>
                    <div className="row">
                        <ul className='list-unstyled p-0 m-0'>
                            <li className='p-4 d-flex justify-content-center crossiconli'>
                                {toggleicon ? <img className='img-fluid' src="./images/Scrizalogo.svg" alt="" /> : <img className='' src="./images/ScrizaSmallLogo.png" alt="" />}<span className="btn-close crossicon" data-bs-dismiss="offcanvas" aria-label="Close" onClick={toggleSidebar}></span>
                            </li>
                            
                            
                            <li className={`p-2 menus borderTOP ${toggleicon? 'actionOptions': ''}`}>
                                <Link to='/' className={`d-flex p-1 text-decoration-none text-black ${toggleicon? '': 'justify-content-center'}`}>
                                    <span className='icon'><Icon icon="ant-design:dashboard-outlined" width="1.5em" height="1.3em"  style={{color: '#000'}} /></span>
                                    <span className={`ms-2  font14 fontweight500 ${toggleicon ? 'itemVisible': 'itemHidden'}`}>Dashboard</span>
                                </Link>
                            </li>
                            
                            <li className='p-2 menus borderTOP'>
                                <Link to='/allSchoolsPage' className={`d-flex p-1 text-decoration-none text-black ${toggleicon? '': 'justify-content-center'}`}>
                                    <span className='icon'><Icon icon="ant-design:dashboard-outlined" width="1.5em" height="1.3em"  style={{color: '#000'}} /></span>
                                    <span className={`ms-2 font14 fontweight500 ${toggleicon ? 'itemVisible': 'itemHidden'}`}>Schools</span>
                                </Link>
                            </li>
                            
                            <li className='p-2 menus borderTOP'>
                                <Link to='/addSchoolsPage' className={`d-flex p-1 text-decoration-none text-black ${toggleicon? '': 'justify-content-center'}`}>
                                    <span className='icon'><Icon icon="ant-design:dashboard-outlined" width="1.5em" height="1.3em"  style={{color: '#000'}} /></span>
                                    <span className={`ms-2 font14 fontweight500 ${toggleicon ? 'itemVisible': 'itemHidden'}`}>Add School</span>
                                </Link>
                            </li>
                            

                            <li className={`p-2 menus borderTOP ${toggleicon ? '': 'addonmenu'}`}>
                                <Link className={`d-flex p-1 text-decoration-none text-black ${toggleicon? '': 'justify-content-center'}`} data-bs-toggle={`${toggleicon? 'collapse': ''}`} to={`${toggleicon? '#addOnCollapse': '/addons'}`} role="button" aria-expanded="false" aria-controls={`${toggleicon? 'addOnCollapse': ''}`}>
                                    <span className='icon'><Icon icon="ant-design:dashboard-outlined" width="1.5em" height="1.3em"  style={{color: '#000'}} /></span>
                                    <span className={`ms-2 font14 fontweight500 ${toggleicon ? 'itemVisible': 'itemHidden'}`}>Addons</span>
                                </Link>
                            </li>
                            
                            <div className="collapse" id="addOnCollapse">
                                <ul className='list-unstyled p-0 m-0'>
                                    <li className='p-2 submenus borderTOP'>
                                        <Link to='/addons' className={`d-flex p-1 text-decoration-none text-black ${toggleicon? '': 'justify-content-center'}`}>
                                            <span className='icon'><Icon icon="ant-design:dashboard-outlined" width="1.5em" height="1.3em"  style={{color: '#000'}} /></span>
                                            <span className={`ms-2 font14 fontweight500 ${toggleicon ? 'subitemVisible': 'subitemHidden addonSubitem'}`}>Addons Details</span>
                                        </Link>
                                    </li>
                                    <li className='p-2 submenus borderTOP'>
                                        <Link to='/addAddons' className={`d-flex p-1 text-decoration-none text-black ${toggleicon? '': 'justify-content-center'}`}>
                                            <span className='icon'><Icon icon="ant-design:dashboard-outlined" width="1.5em" height="1.3em"  style={{color: '#000'}} /></span>
                                            <span className={`ms-2 font14 fontweight500 ${toggleicon ? 'subitemVisible': 'subitemHidden addonSubitem'}`}>Add Addon</span>
                                        </Link>
                                    </li>
                                    <li className='p-2 submenus borderTOP'>
                                        <Link to='/addFeatures' className={`d-flex p-1 text-decoration-none text-black ${toggleicon? '': 'justify-content-center'}`}>
                                            <span className='icon'><Icon icon="ant-design:dashboard-outlined" width="1.5em" height="1.3em"  style={{color: '#000'}} /></span>
                                            <span className={`ms-2 font14 fontweight500 ${toggleicon ? 'subitemVisible': 'subitemHidden addonSubitem'}`}>Features</span>
                                        </Link>
                                    </li>
                                </ul>
                            </div>

                            <div className="addonSubitem">
                                <span>fgvhbj</span>
                            </div>

                            <li className='p-2 menus borderTOP'>
                                <Link to='/subscriptionPage' className={`d-flex p-1 text-decoration-none text-black ${toggleicon? '': 'justify-content-center'}`}>
                                    <span className='icon'><Icon icon="ant-design:dashboard-outlined" width="1.5em" height="1.3em"  style={{color: '#000'}} /></span>
                                    <span className={`ms-2 font14 fontweight500 ${toggleicon ? 'itemVisible': 'itemHidden'}`}>Subscription</span>
                                </Link>
                            </li>
                            <li className='p-2 menus borderTOP'>
                                <Link to='/allPackagesPage' className={`d-flex p-1 text-decoration-none text-black ${toggleicon? '': 'justify-content-center'}`}>
                                    <span className='icon'><Icon icon="ant-design:dashboard-outlined" width="1.5em" height="1.3em"  style={{color: '#000'}} /></span>
                                    <span className={`ms-2 font14 fontweight500 ${toggleicon ? 'itemVisible': 'itemHidden'}`}>Package</span>
                                </Link>
                            </li>
                            <li className='p-2 menus borderTOP borderBottom'>
                                <Link to='/requestPage' className={`d-flex p-1 text-decoration-none text-black ${toggleicon? '': 'justify-content-center'}`}>
                                    <span className='icon'><Icon icon="ant-design:dashboard-outlined" width="1.5em" height="1.3em"  style={{color: '#000'}} /></span>
                                    <span className={`ms-2 font14 fontweight500 ${toggleicon ? 'itemVisible': 'itemHidden'}`}>Request</span>
                                </Link>
                            </li>




                            <li className='p-2 menus'>
                                <span className={`d-flex p-1 text-decoration-none text-black ${toggleicon? '': 'justify-content-center'}`}></span>
                            </li>
                            <li className='p-2 menus'>
                                <span className={`d-flex p-1 text-decoration-none text-black ${toggleicon? '': 'justify-content-center'}`}></span>
                            </li>
                            <li className='p-2 menus'>
                                <span className={`d-flex p-1 text-decoration-none text-black ${toggleicon? '': 'justify-content-center'}`}></span>
                            </li>
                            <li className='p-2 menus'>
                                <span className={`d-flex p-1 text-decoration-none text-black ${toggleicon? '': 'justify-content-center'}`}></span>
                            </li>
                            <li className='p-2 menus'>
                                <span className={`d-flex p-1 text-decoration-none text-black ${toggleicon? '': 'justify-content-center'}`}></span>
                            </li>
                            <li className='p-2 menus'>
                                <span className={`d-flex p-1 text-decoration-none text-black ${toggleicon? '': 'justify-content-center'}`}></span>
                            </li>
{/* ********************** */}
                            
                            <li className='p-2 menus borderTOP'>
                                <Link className={`d-flex p-1 text-decoration-none text-black ${toggleicon? '': 'justify-content-center'}`} data-bs-toggle="collapse" to="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
                                    <span className='icon'><Icon icon="ant-design:dashboard-outlined" width="1.5em" height="1.3em"  style={{color: '#000'}} /></span>
                                    <span className={`ms-2 font14 fontweight500 ${toggleicon ? 'itemVisible': 'itemHidden'}`}>Settings</span>
                                </Link>
                            </li>
                            
                            <div className="collapse" id="collapseExample">
                                <ul className='list-unstyled p-0 m-0'>
                                    <li className='p-2 submenus borderTOP'>
                                        <Link tp='/systemSettingPage' className={`d-flex p-1 text-decoration-none text-black ${toggleicon? '': 'justify-content-center'}`} data-bs-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
                                            <span className='icon'><Icon icon="ant-design:dashboard-outlined" width="1.5em" height="1.3em"  style={{color: '#000'}} /></span>
                                            <span className={`ms-2 font14 fontweight500 ${toggleicon ? 'subitemVisible': 'subitemHidden'}`}>System Setting</span>
                                        </Link>
                                    </li>
                                    <li className='p-2 submenus borderTOP'>
                                        <Link tp='/websiteSettingPage' className={`d-flex p-1 text-decoration-none text-black ${toggleicon? '': 'justify-content-center'}`} data-bs-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
                                            <span className='icon'><Icon icon="ant-design:dashboard-outlined" width="1.5em" height="1.3em"  style={{color: '#000'}} /></span>
                                            <span className={`ms-2 font14 fontweight500 ${toggleicon ? 'subitemVisible': 'subitemHidden'}`}>Website Setting</span>
                                        </Link>
                                    </li>
                                    <li className='p-2 submenus borderTOP'>
                                        <Link tp='/manageFaqPage' className={`d-flex p-1 text-decoration-none text-black ${toggleicon? '': 'justify-content-center'}`} data-bs-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
                                            <span className='icon'><Icon icon="ant-design:dashboard-outlined" width="1.5em" height="1.3em"  style={{color: '#000'}} /></span>
                                            <span className={`ms-2 font14 fontweight500 ${toggleicon ? 'subitemVisible': 'subitemHidden'}`}>Manage Faq</span>
                                        </Link>
                                    </li>
                                    <li className='p-2 submenus borderTOP'>
                                        <Link tp='/paymentSettingPage' className={`d-flex p-1 text-decoration-none text-black ${toggleicon? '': 'justify-content-center'}`} data-bs-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
                                            <span className='icon'><Icon icon="ant-design:dashboard-outlined" width="1.5em" height="1.3em"  style={{color: '#000'}} /></span>
                                            <span className={`ms-2 font14 fontweight500 ${toggleicon ? 'subitemVisible': 'subitemHidden'}`}>Payment Settings</span>
                                        </Link>
                                    </li>
                                </ul>
                            </div>



                            <li className='p-2 menus borderTOP borderBottom'>
                                <Link to='/abc' className={`d-flex p-1 text-decoration-none text-black ${toggleicon? '': 'justify-content-center'}`}>
                                    <span className='icon'><Icon icon="ant-design:dashboard-outlined" width="1.5em" height="1.3em"  style={{color: '#000'}} /></span>
                                    <span className={`ms-2 font14 fontweight500 ${toggleicon ? 'itemVisible': 'itemHidden'}`}>Dashboard</span>
                                </Link>
                            </li>

                            <li className='p-2 menus'>
                                <span className={`d-flex p-1 text-decoration-none text-black ${toggleicon? '': 'justify-content-center'}`}></span>
                            </li>
                            <li className='p-2 menus'>
                                <span className={`d-flex p-1 text-decoration-none text-black ${toggleicon? '': 'justify-content-center'}`}></span>
                            </li>
                            <li className='p-2 menus'>
                                <span className={`d-flex p-1 text-decoration-none text-black ${toggleicon? '': 'justify-content-center'}`}></span>
                            </li>
                            <li className='p-2 menus'>
                                <span className={`d-flex p-1 text-decoration-none text-black ${toggleicon? '': 'justify-content-center'}`}></span>
                            </li>
                        </ul>
                    </div>
                </div>
            </Container>
        </>
    );
};

export default Sidebar;