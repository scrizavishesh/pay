import React, { useEffect, useState } from 'react'
import styled from 'styled-components';
import toast, { Toaster } from 'react-hot-toast';

import  axios  from 'axios';
import {GetApi}  from '../Utils/Apis'

import { Link } from 'react-router-dom';


// ## style css area start ####  

const Container = styled.div`
  .breadcrum-li a{
  text-decoration: none;
  margin-top: 5px;
  color: #008479;
  }
  .main-body{
    background-color: #F2F3F6; 
  }
.main-content-conatainer{
    background-color: #fff;
    margin: 10px;
    /* height: 100vh; */
    border-radius: 8px;

}
/* .margin-minus22{
    margin-top: -18px;
    font-size: 16px;
} */
th, td{
  padding: 10px;
}
.my-td-style-yellow span{
  background-color: #FFEED3;
    color: #FF914C;
    padding: 3px 12px 3px 12px;
    border-radius: 15%;
}
.my-td-style-green span{
  background-color:#E6FFE2;
  color: #00A67E;
  padding: 3px 12px 3px 12px;
  border-radius: 15%;
}
.my-button-drop{
  line-height: 13px !important;
  border: 1px solid #D9D9D9 !important;

}
.pagination-a{
  background-color: #f2f0f0;
  color: #000;
  padding: 0.00175rem 0.25rem;
  margin-left: 0px !important;
}

.page-link-1122 {
    /* padding: 0.00175rem 0.05rem; */
    padding: 0rem 0rem;
}
.pagination-a a{
  gap: 2px;
}
.my-pagina li a:hover{
  background-color: #008479;
  color: #fff;
  border: none;
}
.input-bg{
  background-color: #F2F3F6;
}
.label-color{
  color: #bbbec1;
}
.cont-drop-btn button:hover{
  background-color: transparent;
  color: #000;
  cursor: pointer;
  border: none;
}
.form-focus:focus {
    color: #212529 !important;
    background-color: #fff !important;
    border-color: transparent !important;
    outline: none !important;
    box-shadow: none !important;
}
.form-focus-input:focus {
    color: #212529 !important;
    background-color: #fff !important;
    border-color: 1px solid #ced4da !important;
    outline: none !important;
    box-shadow: none  !important;
}
.form-control:focus {
    border-color: #ced4da !important;
}
.form-select:focus {
    border-color: #ced4da !important;
}

.my-button11{
    display: flex;
    justify-content: center;
    gap: 4px;
    margin-top: 30px;
}

.my-button11 button{
    border-radius: 5px;
  border: 1px solid #ababad;
  color: #000;
font-size: 12px;
}
.my-button11 button:hover{
    background-color: #008479;
    color: #fff;
}
.my-button22{
    display: flex;
    gap: 4px;
    margin-top: 4px;
}

.my-button22 button{
    border-radius: 5px;
  border: 1px solid #ababad;
  color: #000;
font-size: 12px;
}
.my-button22 button:hover{
    background-color: #008479;
    color: #fff;
}
.my-grey{
  color: #ADADBD;
}
.my-div-class p{
  border: 1px solid #ADADBD;
  padding: 10px;
  border-radius: 4px;
  background-color: #F2F3F6;
  color: #ADADBD;
  border: 1px solid #F2F3F6;
}
.my-div-class span a{
    text-decoration: none;
}
.font-red{
    color: #C90303;

}
.font-green{
    color: #00A67E;
}
.anchor-color a{
  color: #8F8F8F;
}
.for-margin-top{
    margin-top: -18px;
    margin-left: 15px;
  }
/* ########## media query ###########  */
 @media only screen and (max-width: 735px) {
  .for-media-query{
    display: flex;
    flex-direction: column;
  }
}
@media only screen and (max-width: 605px) {
    .for-dislay-direction{
        display: flex;
        flex-direction: column;
        margin-bottom: 5px;
    }
}
`;
// ## style css area end ####  


const Subscription = () => {

  const [data, setData] = useState([])
  // console.log(data[0], 'data subscription')

  useEffect(() => {
  showName()
  }, []);  

  const showName = async(id) => {
  try {
    const response = await GetApi();
    // console.log('my-subscription page', response) 

    if (response?.status === 200) {
      toast.success(data?.msg);
      setData(response.data.subscription)
    } else {
      // console.log('fghjkghj')
      toast.error(data?.msg);
    }
  } catch (error) {
    console.log('catch')
}
// console.log('my-dataset',data)
}

    return (
        <Container>
          <div className="container-fluid main-body p-3">
     
         <div className='d-flex justify-content-between for-dislay-direction'>
         <div className="breadCrum ps-2">
         <nav style={{ '--bs-breadcrumb-divider': "'>'" }}aria-label="breadcrumb">
             <ol class="breadcrumb ms-2">
                 <li class="breadcrumb-item active heading-14 font-color" aria-current="page">Home</li>
                 <li class="breadcrumb-item breadcrum-li heading-14" ><Link href="#">Subscriptions</Link></li>
             </ol>
         </nav>
         </div>
     
         <div className='d-flex g-1 for-media-query'>
              <div className='p-0  me-2 heading-14'>
              <button type="submit" class="btn btn-primary mb-3 heading-1 remove-shadow tableActionButtonBgColor text-color-000 heading-14" style={{ border:'1px solid #D9D9D9', lineHeight:'1.3'}}>
                      <svg width="14" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M13 12V14H3V12H2V14C2 14.6 2.4 15 3 15H13C13.6 15 14 14.6 14 14V12H13Z" fill="black"/>
                        <path d="M3 6L3.7 6.7L7.5 2.9V12H8.5V2.9L12.3 6.7L13 6L8 1L3 6Z" fill="black"/>
                      </svg>
                      &nbsp;
                      Export
              </button>
              </div>
         <form class="row  me-2">
             <div class="col-9 ">
                 <input type="password" class="form-control form-control-sm form-focus input-border-color" style={{fontSize:'15px', width:'283px'}} id="inputPassword2" placeholder="01/01/2024 - 02/10/2024" />
             </div>
             <div class="col-3 p-0 ps-2" >
                 <Link type="submit"  class="btn btn-primary mb-3 heading-1 remove-shadow button-bg-color heading-14" style={{ border:'1px solid #008479', lineHeight:'1.3'}}>
                  <svg width="14" height="8" viewBox="0 0 14 8" fill="none" xmlns="http://www.w3.org/2000/svg" style={{marginTop:'-2px'}}>
                          <path d="M4.57143 7.42857C4.57143 7.27702 4.63163 7.13167 4.7388 7.02451C4.84596 6.91735 4.9913 6.85714 5.14286 6.85714H8.57143C8.72298 6.85714 8.86833 6.91735 8.97549 7.02451C9.08265 7.13167 9.14286 7.27702 9.14286 7.42857C9.14286 7.58012 9.08265 7.72547 8.97549 7.83263C8.86833 7.9398 8.72298 8 8.57143 8H5.14286C4.9913 8 4.84596 7.9398 4.7388 7.83263C4.63163 7.72547 4.57143 7.58012 4.57143 7.42857ZM2.28571 4C2.28571 3.84845 2.34592 3.7031 2.45308 3.59594C2.56025 3.48878 2.70559 3.42857 2.85714 3.42857H10.8571C11.0087 3.42857 11.154 3.48878 11.2612 3.59594C11.3684 3.7031 11.4286 3.84845 11.4286 4C11.4286 4.15155 11.3684 4.2969 11.2612 4.40406C11.154 4.51122 11.0087 4.57143 10.8571 4.57143H2.85714C2.70559 4.57143 2.56025 4.51122 2.45308 4.40406C2.34592 4.2969 2.28571 4.15155 2.28571 4ZM0 0.571429C0 0.419876 0.060204 0.274531 0.167368 0.167368C0.274531 0.060204 0.419876 0 0.571429 0H13.1429C13.2944 0 13.4398 0.060204 13.5469 0.167368C13.6541 0.274531 13.7143 0.419876 13.7143 0.571429C13.7143 0.722981 13.6541 0.868326 13.5469 0.975489C13.4398 1.08265 13.2944 1.14286 13.1429 1.14286H0.571429C0.419876 1.14286 0.274531 1.08265 0.167368 0.975489C0.060204 0.868326 0 0.722981 0 0.571429Z" fill="white"/>
                  </svg> &nbsp;
                      Filter
                </Link>
             </div>
        </form>
         <div className='me-2'>
             <div class="input-group mb-3 ">
                 <input type="text" class="form-control form-focus input-border-color " style={{height:'34px'}} placeholder="Search" aria-label="Recipient's username" aria-describedby="basic-addon2" />
                 <span class="input-group-text button-bg-color button-color heading-14" style={{cursor:'pointer',height:"34px"}} id="basic-addon2">Search</span>
             </div>
         </div>
         </div>
        
         </div>
         <h5 className=' mb-3  text-color-000 heading-16 for-margin-top' >Subscriptions Report</h5>
     
         <div className="main-content-conatainer pt-1 ">
                 {/* ###### copy content till here for all component ######  */}
     
        <div className="table-container px-3 table-responsive">
        <table class="table table-sm ">
       <thead className=''>
         <tr className='heading-16 text-color-000' style={{backgroundColor:'  --tableActionButtonBgColor'}}>
           {/* <th className=''>#</th> */}
           <th>ID</th>
           <th>Price  &nbsp; <svg width="12" height="11" viewBox="0 0 12 11" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M8.4 3.05556H6L9 0L12 3.05556H9.6V10.3889H8.4V3.05556ZM0 7.94444H2.3994L2.4 0.611112H3.6V7.94444H6L3 11L0 7.94444Z" fill="black"/>
            </svg>
            </th>
           <th>Package  &nbsp; <svg width="12" height="11" viewBox="0 0 12 11" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M8.4 3.05556H6L9 0L12 3.05556H9.6V10.3889H8.4V3.05556ZM0 7.94444H2.3994L2.4 0.611112H3.6V7.94444H6L3 11L0 7.94444Z" fill="black"/>
            </svg>
          </th>
          <th>Purchase Date  &nbsp; <svg width="12" height="11" viewBox="0 0 12 11" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M8.4 3.05556H6L9 0L12 3.05556H9.6V10.3889H8.4V3.05556ZM0 7.94444H2.3994L2.4 0.611112H3.6V7.94444H6L3 11L0 7.94444Z" fill="black"/>
            </svg>
          </th>
           <th>Email</th>
           <th>Contact No</th>
              <th>Status &nbsp; <svg width="12" height="11" viewBox="0 0 12 11" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M8.4 3.05556H6L9 0L12 3.05556H9.6V10.3889H8.4V3.05556ZM0 7.94444H2.3994L2.4 0.611112H3.6V7.94444H6L3 11L0 7.94444Z" fill="black"/>
                </svg>
                </th>
             <th>Actions</th>
         </tr>
       </thead>
       <tbody className=' align-middle greyTextColor greyText'>
         {
            data.map(item => (
            <tr key={item.id} className='my-bg-color align-middle'>
          
              <td  className=' table-row-bg-color greyText'>{item.subsId}</td>
              <td  className=' table-row-bg-color greyText'>{item.price}</td>
              <td  className=' table-row-bg-color greyText'>{item.plan}</td>
              <td  className=' table-row-bg-color greyText'>{item.purchaseDate}</td>
              <td  className=' table-row-bg-color greyText'>{item.email}</td>
              <td  className=' table-row-bg-color greyText'>{item.phoneNo}</td>
              <td  className=' table-row-bg-color greyText'>{`${item.status === true ? 'Active' : 'InActive'}`}</td>
              <td className=' table-row-bg-color greyText'>
                <div class="dropdown my-button-show">
                    <button class="btn btn-secondary dropdown-togg my-button-drop tableActionButtonBgColor text-color-000 heading-14" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                      Action &nbsp; 
                      <svg width="11" height="7" viewBox="0 0 11 7" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M10.3331 0L11 0.754688L5.5 7L0 0.754688L0.663438 0L5.5 5.48698L10.3331 0Z" fill="black"/>
                        </svg>
                    </button>
                    <ul class="dropdown-menu heading-14 anchor-color heading-14" >
                      <li><Link class="dropdown-item" data-bs-toggle="offcanvas" data-bs-target="#offcanvasRight" aria-controls="offcanvasRight">Edit Subscription</Link></li>
                      <li><a class="dropdown-item" href="#">Delete</a></li>
                    </ul>
                </div>
              </td>
            </tr>
            
          ))}
        
    
       </tbody>
       </table>
        </div>
     
         <div className="row ">
           <div className='d-flex justify-content-between '>
           <div className='heading-13 ps-4'>
           <p>Showing 1 to 10 entries</p>
         </div>
           <div className='pe-4'>
               <nav aria-label="Page navigation example ">
                 <ul class="pagination my-pagina " >
                   <li class="page-item">
                     <a class="page-link pagination-a" href="#" aria-label="Previous">
                       <span aria-hidden="true">
                          <svg width="8" height="14" viewBox="0 0 8 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M8 0.84875L7.1375 0L0 7L7.1375 14L8 13.1556L1.72917 7L8 0.84875Z" fill="black"/>
                          </svg>
                      </span>
                     </a>
                     &nbsp;
                   </li>
                   &nbsp;
                   <li class="page-item"><a class="page-link pagination-a" href="#">1</a></li>&nbsp;
                   <li class="page-item"><a class="page-link pagination-a" href="#">2</a></li>&nbsp;
                   <li class="page-item"><a class="page-link pagination-a" href="#">3</a></li>&nbsp;
                   <li class="page-item"><a class="page-link pagination-a" href="#">4</a></li>&nbsp;
                   <li class="page-item"><a class="page-link pagination-a" href="#">5</a></li>&nbsp;
                   <li class="page-item">
                     <a class="page-link pagination-a" href="#" aria-label="Next" >
                       <span aria-hidden="true">
                       <svg width="8" height="14" viewBox="0 0 8 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path d="M0 0.84875L0.8625 0L8 7L0.8625 14L0 13.1556L6.27083 7L0 0.84875Z" fill="black"/>
                       </svg>
                       </span>
                     </a>
                   </li>
                 </ul>
               </nav>
           </div>
           </div>
     
         </div>
             </div>
                      {/* ########################## edit offcanvas  start ################  */}
                 <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasRight" aria-labelledby="offcanvasRightLabel">
                          <div className="container-fluid">
                              <div class="offcanvas-header">
                               <Link  data-bs-dismiss="offcanvas" ><svg width="28" height="15" viewBox="0 0 28 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M8.06 0.295798C8.15373 0.388761 8.22812 0.499362 8.27889 0.621222C8.32966 0.743081 8.3558 0.873786 8.3558 1.0058C8.3558 1.13781 8.32966 1.26852 8.27889 1.39038C8.22812 1.51223 8.15373 1.62284 8.06 1.7158L3.46 6.3158H27C27.2652 6.3158 27.5196 6.42115 27.7071 6.60869C27.8946 6.79623 28 7.05058 28 7.3158C28 7.58102 27.8946 7.83537 27.7071 8.0229C27.5196 8.21044 27.2652 8.3158 27 8.3158H3.48L8.06 12.8858C8.24625 13.0732 8.35079 13.3266 8.35079 13.5908C8.35079 13.855 8.24625 14.1084 8.06 14.2958C7.87264 14.482 7.61918 14.5866 7.355 14.5866C7.09081 14.5866 6.83736 14.482 6.65 14.2958L0.289999 7.9358C0.204397 7.85367 0.136286 7.75508 0.089756 7.64596C0.0432262 7.53683 0.0192413 7.41943 0.0192413 7.3008C0.0192413 7.18217 0.0432262 7.06476 0.089756 6.95564C0.136286 6.84652 0.204397 6.74793 0.289999 6.6658L6.64 0.295798C6.73296 0.20207 6.84356 0.127676 6.96542 0.0769072C7.08728 0.0261385 7.21799 0 7.35 0C7.48201 0 7.61272 0.0261385 7.73458 0.0769072C7.85643 0.127676 7.96704 0.20207 8.06 0.295798Z" fill="#008479"/>
                                </svg>
                                </Link>
                               <h5 class="offcanvas-title heading-16" id="offcanvasRightLabel">Subscription Edit</h5>
                             </div>
                             <hr className='' style={{marginTop:'-3px'}}/>
                           <div className="inputs">
     
                             <div class="mb-3" style={{marginTop:'-4px'}}>
                             <label for="exampleFormControlInput1" class="form-label label-color ">ID</label>
                             <input type="email" class="form-control form-focus input-bg label-color" style={{marginTop:'-4px'}} id="exampleFormControlInput1" placeholder="SCR152" /> 
                             </div>
                           </div>
     
                             <div class="mb-3" style={{marginTop:'-6px'}}>
                             <label for="exampleFormControlInput1" class="form-label label-color ">Price</label>
                             <input type="email" class="form-control form-focus" style={{marginTop:'-4px'}} id="exampleFormControlInput1" placeholder="600" /> 
                             </div>
     
                             <div class="mb-3" style={{marginTop:'-6px'}}>
                             <label for="exampleFormControlInput1" class="form-label label-color ">Package</label>
                             {/* <input type="email" class="form-control input-bg label-color" style={{marginTop:'-4px'}} id="exampleFormControlInput1" placeholder="xyz12@gmail.com" />  */}
                             <select class="form-select form-focus" aria-label="Default select example">
                                 <option selected>Silver</option>
                                 <option value="1">One</option>
                                 <option value="2">Two</option>
                                 <option value="3">Three</option>
                               </select>
                             </div>

                             <div class="mb-3" style={{marginTop:'-6px'}}>
                             <label for="exampleFormControlInput1" class="form-label label-color ">Purchase Date</label>
                             <input type="email" class="form-control form-focus" style={{marginTop:'-4px'}} id="exampleFormControlInput1" placeholder="01 Feb 2023" /> 
                             </div>
                             <div class="mb-3" style={{marginTop:'-6px'}}>
                             <label for="exampleFormControlInput1" class="form-label label-color ">Email</label>
                             <input type="email" class="form-control form-focus input-bg label-color" style={{marginTop:'-4px'}} id="exampleFormControlInput1" placeholder="xyz12@gmail.com" /> 
                             </div>

                               <div style={{marginTop:'-4px'}}>
                               <label for="exampleFormControlTextarea1" class="form-label label-color">Contact No</label>
                             <div class="input-group mb-3 cont-drop-btn">
                                 <button class="btn btn-outline-secondary dropdown-toggle" style={{border:'1px solid #ced4da'}} type="button" data-bs-toggle="dropdown" aria-expanded="false">+91</button>
                                 <ul class="dropdown-menu">
                                   <li><a class="dropdown-item" href="#">Action</a></li>
                                   <li><a class="dropdown-item" href="#">Another action</a></li>
                                   <li><a class="dropdown-item" href="#">Something else here</a></li>
                                   <li><hr class="dropdown-divider" /> </li>
                                   <li><a class="dropdown-item" href="#">Separated link</a></li>
                                 </ul>
                                 <input type="number" class="form-control form-focus" aria-label="Text input with dropdown button" />
                             </div>
                               </div>
                           <div style={{marginTop:'-4px'}}>
                           <label for="exampleFormControlTextarea1" class="form-label label-color">Status</label>
                           <select class="form-select form-focus" aria-label="Default select example">
                                 <option selected>Active</option>
                                 <option value="1">One</option>
                                 <option value="2">Two</option>
                                 <option value="3">Three</option>
                               </select>
                           </div>
                                 <div className='my-button11 '>
                           <button type="button" class="btn btn-outline-success" onClick={(e)=>{UpdateHandleBtn()}}>Update</button>
                           <button type="button" class="btn btn-outline-success">Cancel</button>
                           </div>
                         </div>
     
                 </div>
     
                      {/* ########################## edit offcanvas  end  ################  */}
     
         </div>
        </Container>
       )
}

export default Subscription
